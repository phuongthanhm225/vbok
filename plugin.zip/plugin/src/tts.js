load("voice_list.js");

function execute(text, voice) {
    // voiceInfo.id chính là mã voice truyền từ VBook (ví dụ: vi_vn_001)
    let voiceInfo = voices.find(function (e) {
        return e.id == voice;
    });

    let voiceId = voiceInfo ? voiceInfo.id : voice;

    // Gọi đến server Vercel của bạn
    let response = fetch("https://express-js-on-vercel-henna-theta-13.vercel.app/api/generate-tts", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        },
        body: JSON.stringify({
            "text": text,
            "voice_id": voiceId // Khớp với const { text, voice_id } trong code Vercel
        })
    });

    if (response.ok) {
        let resText = response.text();
        if (resText.startsWith('{')) {
            let result = JSON.parse(resText);
            
            // Dựa trên code Vercel: if (response.data.status_code === 0)
            if (result.success) {
                // Trả về chuỗi v_str (đây là base64 của audio)
                return Response.success(result.data);
            } else {
                return Response.error(result.message || "Lỗi từ TikTok API");
            }
        }
    }

    return Response.error("Không thể kết nối đến máy chủ Vercel. Vui lòng kiểm tra lại log.");
}